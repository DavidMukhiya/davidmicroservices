package com.zorba.controller;

import java.math.BigDecimal;
import java.net.URI;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.loadbalancer.LoadBalancerClient;
import org.springframework.core.env.Environment;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.zorba.bean.CurrencyConversionBean;
import com.zorba.proxy.CurrencyExchangeServiceProxy;

@RestController
public class CurrencyConversionController {

	@Autowired
	Environment environment;
	
	@Autowired
	CurrencyExchangeServiceProxy currencyExchangeServiceProxy;
	
	@Autowired
	 private LoadBalancerClient loadBalancer;

	@GetMapping("/currency-conversion/from/{from}/to/{to}/amount/{amount}/toEmail/{toEmail}")
	public CurrencyConversionBean convertCurrency(@PathVariable String from, @PathVariable String to,
			@PathVariable BigDecimal amount,@PathVariable String toEmail) {

		//Use ribbon as load-balancer
		
		ServiceInstance instance = loadBalancer.choose("currency-exchange-service");
        URI storesUri = URI.create(String.format("http://%s:%s", instance.getHost(), instance.getPort()));

		// Holding URL Variable

		Map<String, String> urlVariables = new HashMap<>();
		urlVariables.put("from", from);
		urlVariables.put("to", to);
		
		Map<String, String> urlVariablesEmail = new HashMap<>();
		urlVariablesEmail.put("toEmail", toEmail);

		// Calling Currency-exchange-service

		ResponseEntity<CurrencyConversionBean> responseEntity = new RestTemplate().getForEntity(
				storesUri+"/currency-exchange/from/{from}/to/{to}", CurrencyConversionBean.class,
				urlVariables);
		
		// Calling email service 
		ResponseEntity<String> responseEntityEmail = new RestTemplate().getForEntity(
				"http://localhost:8083/sendMail/toEmail/{toEmail}", String.class,
				urlVariablesEmail);

        System.out.println(responseEntityEmail.getBody());
		CurrencyConversionBean response = responseEntity.getBody();
		BigDecimal totalConvertedAmount = amount.multiply(response.getConversionMultiple());

		return new CurrencyConversionBean(response.getId(), from, to, response.getConversionMultiple(), amount,
				totalConvertedAmount, response.getPort(),responseEntityEmail.getBody());
	}

	@GetMapping("/currency-conversion-feign/from/{from}/to/{to}/amount/{amount}")
	public CurrencyConversionBean convertCurrencyFeign(@PathVariable String from, @PathVariable String to,
			@PathVariable BigDecimal amount) {
		//calling currency exchange by using feign client
		CurrencyConversionBean response = currencyExchangeServiceProxy.retriveExchangeService(from, to);
		BigDecimal totalConvertedAmount = amount.multiply(response.getConversionMultiple());
		
		return new CurrencyConversionBean(response.getId(), from, to, response.getConversionMultiple(), amount,
				totalConvertedAmount, response.getPort(),"");

	}
}
