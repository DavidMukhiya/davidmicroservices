package com.zorba;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.netflix.ribbon.RibbonClient;
import org.springframework.cloud.openfeign.EnableFeignClients;

import com.zorba.configuraton.RibbonConfiguration;

@SpringBootApplication
@EnableFeignClients("com.zorba")
@EnableDiscoveryClient
@RibbonClient(name="server",configuration=RibbonConfiguration.class)
public class CurrencyConversionServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(CurrencyConversionServiceApplication.class, args);
	}

}
