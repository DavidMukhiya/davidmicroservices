package com.zorba.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.zorba.entity.ExchangeValue;
import com.zorba.repository.ExchangeValueRepository;


@RestController
public class CurrencyExchangeController {
	
	@Autowired
	Environment environment;
	@Autowired
	ExchangeValueRepository exchangeValueRepository;
	
	@GetMapping("/currency-exchange/from/{from}/to/{to}")
	public ExchangeValue getExchangeValue(@PathVariable String from,@PathVariable String to) {
		//ExchangeValue ev = new ExchangeValue(1000l, from, to, BigDecimal.valueOf(72));
		ExchangeValue ev = exchangeValueRepository.findByFromAndTo(from,to);
		ev.setPort(Integer.parseInt(environment.getProperty("local.server.port")));
		return ev;
	}
	
	@GetMapping("/currency-exchange/getAll")
	public List<ExchangeValue> getExchangeValue() {
		
		return exchangeValueRepository.findAll();
	}
}
