package com.zorba.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties("email-service")
public class EmailConfiguration{

	
		private String email;
		private String domain;
		
		public EmailConfiguration() {
			
		}
		
		public EmailConfiguration(String email, String domain) {
			super();
			this.email = email;
			this.domain = domain;
		}
		public String getEmail() {
			return email;
		}
		public void setEmail(String email) {
			this.email = email;
		}
		public String getDomain() {
			return domain;
		}
		public void setDomain(String domain) {
			this.domain = domain;
		}
		
		
}
